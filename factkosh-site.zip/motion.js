(function(){
  var reduce=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
  var bar=document.querySelector(".progress i"),head=document.querySelector(".top");
  var lastY=window.scrollY||0,ticking=false;
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function update(){
    var y=window.scrollY||0,h=document.documentElement.scrollHeight-window.innerHeight;
    if(bar)bar.style.transform="scaleX("+(h>0?clamp(y/h,0,1):0)+")";
    if(head){if(y>lastY+6&&y>140)head.classList.add("hide");else if(y<lastY-6||y<80)head.classList.remove("hide");}
    lastY=y;
    if(!reduce){
      var els=document.querySelectorAll(".plx");
      for(var i=0;i<els.length;i++){
        var el=els[i],p=el.parentElement;if(!p||!p.offsetParent)continue;
        var r=p.getBoundingClientRect();if(r.bottom<-100||r.top>window.innerHeight+100)continue;
        var k=parseFloat(el.getAttribute("data-speed")||"0.12"),lim=parseFloat(el.getAttribute("data-limit")||"30");
        var off=clamp((r.top+r.height/2-window.innerHeight/2)*k*-1,-lim,lim);
        el.style.setProperty("--py",off.toFixed(1)+"px");
      }
    }
    ticking=false;
  }
  window.addEventListener("scroll",function(){if(!ticking){ticking=true;requestAnimationFrame(update);}},{passive:true});
  window.addEventListener("resize",update);
  var io=null;
  function init(){
    var els=document.querySelectorAll(".reveal:not(.in)");
    if(reduce||!("IntersectionObserver" in window)){for(var i=0;i<els.length;i++)els[i].classList.add("in");update();return;}
    if(!io)io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting){en.target.classList.add("in");io.unobserve(en.target);}});},{threshold:.2,rootMargin:"0px 0px -6% 0px"});
    for(var j=0;j<els.length;j++)io.observe(els[j]);
    update();
  }
  window.FKinit=init;window.FKupdate=function(){lastY=0;update();};
  init();
})();