(function(){
  var CLIENT="ca-pub-XXXXXXXXXXXXXXXX";
  var SLOTS={top:"SLOT_ID_TOP",mid:"SLOT_ID_MID"};
  var live=CLIENT.indexOf("XXXX")===-1;
  document.querySelectorAll(".ad").forEach(function(a){
    var box=a.querySelector(".ad-box"),id=SLOTS[a.getAttribute("data-slot")];
    if(live&&id&&id.indexOf("SLOT_ID")===-1){
      box.innerHTML='<ins class="adsbygoogle" style="display:block" data-ad-client="'+CLIENT+'" data-ad-slot="'+id+'" data-ad-format="auto" data-full-width-responsive="true"></ins>';
      try{(window.adsbygoogle=window.adsbygoogle||[]).push({});}catch(e){}
    }else{box.textContent="Ad space";box.classList.add("ph");}
  });
  var y=document.getElementById("yr");if(y)y.textContent=new Date().getFullYear();
})();
